package com.dandan.album;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int REQ_FILE = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.setStatusBarColor(Color.parseColor("#FAF8F6"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.parseColor("#FAF8F6"));

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            s.setMediaPlaybackRequiresUserGesture(false);
        }

        webView.addJavascriptInterface(new AlbumBridge(), "Android");
        webView.addJavascriptInterface(new DeviceBridge(), "Device");
        webView.addJavascriptInterface(new UpdateBridge(), "Updater");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "选择照片"), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        setContentView(webView);
        loadWebContent();
        registerUpdateReceiver();
        checkUpdate();
    }

    /** 加载页面：优先加载云端热更新过的 index.html */
    private void loadWebContent() {
        File hot = new File(getFilesDir(), "web/index.html");
        if (hot.exists() && hot.length() > 2000) {
            webView.loadUrl("file://" + hot.getAbsolutePath());
        } else {
            webView.loadUrl("file:///android_asset/index.html");
        }
    }

    /* ================= 云更新 ================= */

    private long downloadId = -1;
    private BroadcastReceiver updateReceiver;

    private SharedPreferences sp() {
        return getSharedPreferences("update", Context.MODE_PRIVATE);
    }

    private void registerUpdateReceiver() {
        updateReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
                long want = sp().getLong("download_id", -1);
                if (id != -1 && id == want) {
                    installApk(id);
                }
            }
        };
        IntentFilter filter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(updateReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(updateReceiver, filter);
        }
    }

    /** 读取 version.json，检查网页热更新与新版本 APK */
    private void checkUpdate() {
        String override = sp().getString("url", "");
        final String base = (override != null && override.trim().length() > 0)
                ? override.trim() : getString(R.string.update_url);
        if (base == null || base.trim().isEmpty()) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, "还没配置更新地址", Toast.LENGTH_SHORT).show();
                }
            });
            return;
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String json = httpGet(base.trim());
                    org.json.JSONObject o = new org.json.JSONObject(json);

                    // 1）网页热更新：只替换界面，不用重装
                    String webUrl = o.optString("webUrl", "");
                    int webVersion = o.optInt("webVersion", 0);
                    if (webUrl.length() > 0 && webVersion > sp().getInt("web_version", 0)) {
                        String html = httpGet(webUrl);
                        if (html != null && html.length() > 2000) {
                            File dir = new File(getFilesDir(), "web");
                            if (!dir.exists()) dir.mkdirs();
                            File f = new File(dir, "index.html");
                            FileOutputStream fos = new FileOutputStream(f);
                            fos.write(html.getBytes("UTF-8"));
                            fos.close();
                            sp().edit().putInt("web_version", webVersion).apply();
                        }
                    }

                    // 2）整包更新：APK 版本更高时提示下载安装
                    final int newCode = o.optInt("versionCode", 0);
                    final String apkUrl = o.optString("apkUrl", "");
                    final String notes = o.optString("notes", "");
                    if (newCode > 0 && apkUrl.length() > 0 && newCode > currentVersionCode()) {
                        final String finalApk = apkUrl.startsWith("http") ? apkUrl
                                : base.substring(0, base.lastIndexOf('/') + 1) + apkUrl;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("发现新版本")
                                        .setMessage(notes.length() > 0 ? notes : "有新版本可以更新")
                                        .setPositiveButton("立即更新", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface d, int w) {
                                                downloadApk(finalApk);
                                            }
                                        })
                                        .setNegativeButton("稍后", null)
                                        .show();
                            }
                        });
                    }
                } catch (Exception ignored) {
                }
            }
        }).start();
    }

    private String httpGet(String url) throws Exception {
        java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(20000);
        c.setRequestProperty("Cache-Control", "no-cache");
        java.io.InputStream in = c.getInputStream();
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        c.disconnect();
        return new String(bo.toByteArray(), "UTF-8");
    }

    private int currentVersionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 1;
        }
    }

    private void downloadApk(String url) {
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle("周盼盼的小相册 新版本");
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, "album_update.apk");
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            downloadId = dm.enqueue(req);
            sp().edit().putLong("download_id", downloadId).apply();
            Toast.makeText(this, "开始下载更新⋯⋯", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "下载失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void installApk(long id) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                Toast.makeText(this, "请允许安装未知应用后重试", Toast.LENGTH_LONG).show();
                Intent set = new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + getPackageName()));
                startActivity(set);
                return;
            }
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            Uri uri = dm.getUriForDownloadedFile(id);
            Intent it = new Intent(Intent.ACTION_VIEW);
            it.setDataAndType(uri, "application/vnd.android.package-archive");
            it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(it);
        } catch (Exception e) {
            Toast.makeText(this, "安装失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** 设备唯一标识，用于离线激活码 */
    private class DeviceBridge {
        @JavascriptInterface
        public String getDeviceId() {
            try {
                String id = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
                return id == null ? "" : id;
            } catch (Exception e) {
                return "";
            }
        }
    }

    /** 云更新配置桥 */
    private class UpdateBridge {
        @JavascriptInterface
        public void setUpdateUrl(String url) {
            sp().edit().putString("url", url == null ? "" : url.trim()).apply();
        }

        @JavascriptInterface
        public String getUpdateUrl() {
            String u = sp().getString("url", "");
            return u == null ? "" : u;
        }

        @JavascriptInterface
        public void checkNow() {
            checkUpdate();
        }
    }

    /** 把合成好的照片写入手机相册 */
    private class AlbumBridge {
        @JavascriptInterface
        public boolean saveImage(String dataUrl, String name) {
            try {
                int comma = dataUrl.indexOf(',');
                if (comma < 0) return false;
                byte[] bytes = Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
                String fileName = name + "_" + System.currentTimeMillis() + ".jpg";

                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH,
                            Environment.DIRECTORY_PICTURES + "/周盼盼的小相册");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    OutputStream out = getContentResolver().openOutputStream(uri);
                    if (out == null) return false;
                    out.write(bytes);
                    out.close();
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                    return true;
                } else {
                    File dir = new File(Environment.getExternalStoragePublicDirectory(
                            Environment.DIRECTORY_PICTURES), "周盼盼的小相册");
                    if (!dir.exists() && !dir.mkdirs()) return false;
                    File file = new File(dir, fileName);
                    FileOutputStream fos = new FileOutputStream(file);
                    fos.write(bytes);
                    fos.close();
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    ClipData clip = data.getClipData();
                    if (clip != null && clip.getItemCount() > 0) {
                        ArrayList<Uri> uris = new ArrayList<>();
                        for (int i = 0; i < clip.getItemCount(); i++) {
                            Uri u = clip.getItemAt(i).getUri();
                            if (u != null) uris.add(u);
                        }
                        result = uris.toArray(new Uri[0]);
                    } else if (data.getData() != null) {
                        result = new Uri[]{ data.getData() };
                    }
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript(
                "(function(){try{return window.__albumBack?String(window.__albumBack()):'false';}catch(e){return 'false';}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String value) {
                        if (!"\"true\"".equals(value)) {
                            MainActivity.super.onBackPressed();
                        }
                    }
                });
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        try {
            if (updateReceiver != null) unregisterReceiver(updateReceiver);
        } catch (Exception ignored) {
        }
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
