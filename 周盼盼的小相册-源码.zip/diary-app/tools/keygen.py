# 周盼盼的小相册 · 离线激活码生成器
ALPHA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'

def fnv(s):
    h = 2166136261
    for ch in s:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return h

def hx(s, n):
    return ''.join(ALPHA[fnv(s + '#' + str(i)) & 31] for i in range(n))

def norm(s):
    return ''.join(c for c in s.upper() if c.isalnum())

def device_code(android_id):
    c = hx('dev|' + android_id, 8)
    return c[:4] + '-' + c[4:]

def gen_code(dev):
    c = hx('zpp|' + norm(dev), 16)
    return c[:4] + '-' + c[4:8] + '-' + c[8:12] + '-' + c[12:]

if __name__ == '__main__':
    import sys
    print('输入 App 显示的设备码（如 A1B2-C3D4）：')
    dev = input().strip()
    print('激活码：', gen_code(dev))
    input('按回车退出')
