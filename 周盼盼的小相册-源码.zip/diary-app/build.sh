#!/bin/bash
set -e
SDK=/home/user/android-sdk
BT=$SDK/bt/android-14
PLAT=$SDK/android-35/android.jar
JDK=$SDK/jdk-17.0.21+9
export JAVA_HOME=$JDK
export PATH=$JDK/bin:$PATH
cd /home/user/Doubao/chats/22523276611833090/diary-app
rm -rf build && mkdir -p build/gen build/classes build/dex

"$BT/aapt2" compile --dir res -o build/res.zip
"$BT/aapt2" link -o build/unaligned.apk \
  -I "$PLAT" \
  --manifest AndroidManifest.xml \
  -A assets \
  -R build/res.zip \
  --java build/gen \
  --min-sdk-version 21 --target-sdk-version 34 \
  --auto-add-overlay \
  --version-code 4 --version-name 1.3

javac -source 8 -target 8 -encoding UTF-8 \
  -bootclasspath "$PLAT" \
  -classpath "$PLAT" \
  -d build/classes \
  build/gen/com/dandan/album/R.java \
  src/com/dandan/album/MainActivity.java 2>&1 | grep -v "bootstrap class path" || true

"$BT/d8" --lib "$PLAT" --min-api 21 --output build/dex $(find build/classes -name '*.class')

cd build
cp unaligned.apk work.apk
zip -q -j work.apk dex/classes.dex
"$BT/zipalign" -f -p 4 work.apk aligned.apk

if [ ! -f ../release.keystore ]; then
  keytool -genkeypair -v -keystore ../release.keystore -storepass dandan2026 -keypass dandan2026 \
    -alias dandan -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Dandan Album, OU=App, O=Dandan, L=Jingdezhen, ST=Jiangxi, C=CN" >/dev/null 2>&1
fi

"$BT/apksigner" sign --ks ../release.keystore --ks-pass pass:dandan2026 --key-pass pass:dandan2026 \
  --ks-key-alias dandan --out ../周盼盼的小相册.apk aligned.apk
"$BT/apksigner" verify ../周盼盼的小相册.apk
ls -lh ../周盼盼的小相册.apk
echo BUILD_OK
