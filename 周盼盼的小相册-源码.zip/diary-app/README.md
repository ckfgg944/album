# 周盼盼的小相册

一个离线安卓相册 App：瀑布流排版、相簿分组、贴纸编辑、合成保存到手机相册、离线激活码。

- 包名：`com.dandan.album`
- 版本：1.1（versionCode 2）
- 最低支持：Android 5.0
- 图标：内置猫咪头像

## 功能

| 功能 | 说明 |
|---|---|
| 照片导入 | 一次可多选，自动压缩到 1600px 内、JPEG 0.82 |
| 排版 | 双列瀑布流，圆角 + 淡阴影 |
| 相簿 | 默认「日常」「表情包」，可新建相簿，单张照片可“移到相簿” |
| 贴纸 | 18 个表情贴纸，可拖动、滑杆缩放、单独删除 |
| 导出 | 合成贴纸后保存到 `Pictures/周盼盼的小相册/` |
| 激活 | 离线设备码激活，不联网校验 |

内置了 5 张示例照片（日常 x4、表情包 x1），首次启动自动写入。

## 离线激活

1. 首次打开 App，锁屏会显示 **设备码**，例如 `M2T8-ZE7L`
2. 用 `tools/keygen.html`（手机/电脑浏览器打开）或 `python3 tools/keygen.py` 输入设备码生成激活码
3. 在 App 输入激活码即永久激活
4. 主控码（你自己用，跳过设备绑定）：`ZPP-8888-8888-8888`

算法：FNV-1a 哈希 + 自定义 Base32，激活码 16 位分 4 组，与本机设备码绑定。换机需重新生成。

> 注意：这是自用版权保护，不是售卖卡密系统。

## 云更新（不用重新找安装包）

App 已内置更新模块，但默认关闭。启用步骤：

1. 打开 `res/values/strings.xml`，把 `update_url` 填成你 `version.json` 的完整地址：

```xml
<string name="update_url">https://你的域名/album/version.json</string>
```

2. 托管目录里放两个文件：

`version.json`

```json
{
  "versionCode": 3,
  "versionName": "1.2",
  "apkUrl": "album-1.2.apk",
  "notes": "新增：照片分组重命名、贴纸更多",
  "webVersion": 2,
  "webUrl": "https://你的域名/album/index.html"
}
```

3. 免费静态托管方案（不需要服务器/端口）：
   - GitHub Pages：建仓库 → Settings → Pages → 上传 `version.json` 和 APK
   - Cloudflare Pages：直接拖文件夹上传
   - Gitee Pages：国内访问更稳，需实名

行为说明：
- `versionCode` 大于当前版本 → 弹「发现新版本」→ 下载 APK → 调起系统安装（需允许“安装未知应用”）
- `webVersion` 更大 → 自动下载 `index.html` 到 App 私有目录，下次启动直接加载，**界面改动无需重装**
- 只改界面/贴纸/相簿逻辑时，优先用 `webVersion` 热更新；改了原生部分（权限、相册写入、激活）才需要发 APK

## 源码结构

```
AndroidManifest.xml              清单（网络、安装包权限）
assets/index.html                相册全部界面与逻辑（IndexedDB 存图、贴纸、激活）
assets/seed.js                   内置的 5 张示例照片（base64）
assets/icon.png                  激活页头像
src/com/dandan/album/MainActivity.java
                                  WebView 外壳、多选相册、保存到系统相册、
                                  设备码、云更新（下载/安装/网页热更新）
res/                             图标、名称、update_url 配置
build.sh                         一键打包（aapt2 → javac → d8 → zipalign → apksigner）
tools/keygen.html                激活码生成器（网页版）
tools/keygen.py                  激活码生成器（命令行版）
```

## 重新打包

需要 JDK 17 + Android SDK（platform-35 / build-tools 34）：

```bash
bash build.sh
```

产物：`周盼盼的小相册.apk`（已签名，v1/v2/v3 签名方案）。

## 签名

`build.sh` 会自动生成并复用 `release.keystore`（口令 `dandan2026`，alias `dandan`）。
**这个 keystore 一定要备份**，后续更新必须用同一个签名，否则无法覆盖安装。
